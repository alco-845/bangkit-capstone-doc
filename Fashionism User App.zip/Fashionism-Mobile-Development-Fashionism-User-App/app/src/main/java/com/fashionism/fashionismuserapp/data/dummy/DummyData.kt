package com.fashionism.fashionismuserapp.data.dummy

data class DummyData(
    val id: Int,
    val name: String,
    val imageOne: Int,
    val price: String,
    val storeName: String,
)