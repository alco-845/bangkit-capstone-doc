package com.fashionism.fashionismuserapp.data.db
// not really need db, but in case i need, i would use this file to make an offline database
//class AppDatabase {
//}