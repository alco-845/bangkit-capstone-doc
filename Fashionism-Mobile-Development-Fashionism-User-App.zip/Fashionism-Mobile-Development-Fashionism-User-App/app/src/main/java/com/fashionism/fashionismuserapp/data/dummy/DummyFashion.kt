package com.fashionism.fashionismuserapp.data.dummy

import com.fashionism.fashionismuserapp.R

object DummyFashion {
    val dummy = listOf(
        DummyData(1, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(2, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(3, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(4, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(5, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(6, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(7, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(8, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(9, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        DummyData(10, "Fashion 1", R.drawable.dummy_baju, "Rp. 100.000", "Store 1"),
        )
}