package com.fashionism.fashionismuserapp.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.fashionism.fashionismuserapp.R

class AwaitDataActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_await_data)
    }
}