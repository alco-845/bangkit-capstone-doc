package com.alcorp.fashionism_umkm.ui.profile.edit_profile

import androidx.lifecycle.ViewModel
import com.alcorp.fashionism_umkm.data.AppRepository

class EditProfileViewModel(private val repository: AppRepository) : ViewModel() {
}