package com.alcorp.fashionism_umkm.ui.auth.signup

import androidx.lifecycle.ViewModel
import com.alcorp.fashionism_umkm.data.AppRepository

class SignUpViewModel(private val repository: AppRepository) : ViewModel() {
}