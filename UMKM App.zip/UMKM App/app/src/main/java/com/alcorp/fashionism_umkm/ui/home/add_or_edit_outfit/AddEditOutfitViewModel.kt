package com.alcorp.fashionism_umkm.ui.home.add_or_edit_outfit

import androidx.lifecycle.ViewModel
import com.alcorp.fashionism_umkm.data.AppRepository

class AddEditOutfitViewModel(private val repository: AppRepository) : ViewModel() {
}